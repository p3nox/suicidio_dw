const { Pool } = require('pg');

const pool = new Pool({
    user: 'ifms-dw2',
    host: 'localhost',
    database: 'ifms-dw2',
    password: 'ifms-dw2',
    port: 5432
})

module.exports = pool;