Handlebars.registerHelper("listing", function(list) {

    pool.query(`SELECT id, nome, raca, idade
                FROM doges ORDER BY ID ASC`)
        .then((array) => {

            let listaDoges = array.rows


            return res.render("list" , {listaDoges , vazio});

        })
        .catch((err) => {

            console.log(err.stack)

        })
    return html;
});