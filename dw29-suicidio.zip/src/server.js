const express = require("express");
const app = express();
const {engine} = require('express-handlebars');

const port = 5080


 /**
 * Configuração do parser para requisições post
 */
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}))
app.use(express.static('public'))




app.set('views', __dirname + '/views');
app.engine('.hbs', engine({ defaultLayout: 'planB', extname: '.hbs' }));
app.set('view engine', '.hbs');





/**
 * caminhos estaticos
 * ./           -> indica o diretório raiz do projeto
 * __dirname    -> retorna o diretório do arquivo que está sendo executado, no caso, o server.js
 */
app.use('/bscss', express.static('./node_modules/bootstrap/dist/css'));
app.use('/bsjs', express.static('./node_modules/bootstrap/dist/js'));
app.use('/popperjs', express.static('./node_modules/@popperjs/core/dist/umd'));
app.use('/jquery', express.static('./node_modules/jquery/dist'));
app.use('/mask', express.static('./node_modules/jquery-mask-plugin/dist'));
app.use('/publico', express.static(__dirname + '/publico'));
app.use('/vendor', express.static(__dirname + '/publico/vendor'));
 

/**
 * Conexão com banco de dados via pool de conexões
 * https://node-postgres.com/
 */
const pool = require('./dao/connection');

/**
 * Requisições
 */


function listagem (){

    let listaObjetos

    pool.query(`
    SELECT aidi, nome, raca, idade
	                FROM doges ORDER BY AIDI ASC
    `)
        .then(function (array) {

            listaObjetos = array.rows



        })
        .catch(function (erro) {
            console.log("erro" + erro);
        })
    console.log(listaObjetos);
    return listaObjetos;
}


app.get('/', (req, res) => {
//instead of res.render('main', {layouts: 'index'});

    pool.query(`
    SELECT aidi, nome, raca, idade
	                FROM doges ORDER BY AIDI ASC
    `)
        .then(function (array) {

          let listaObjetos = array.rows

            res.render("main" , {listaObjetos})

        })
        .catch(function (erro) {
            console.log("erro" + erro);
        })

});


app.get('/form',function(req, res){
    res.render('form');
});

app.post('/cadastro-album',function(req, res){

    pool.query(`
                INSERT INTO doges 
		            (nome, raca, idade) 
	            VALUES
                    ($1, $2, $3)`,
                    [req.body.nome, 
                        req.body.raca,
                        req.body.idade]
                )
                .then(function(retorno){
                    console.log('Cadastro realizado com sucesso!');
                    let mensagem = "Cadastro realizado com sucesso!"
                    res.render('form-album',{mensagem})
                })
                .catch(function(erro){
                    console.log('Apresentou erro: ' + erro);
                    let mensagem = "Ops! Tivemos problemas com esta solicitação"
                    res.render('form-album',{mensagem})
                })
});

/*app.get('/try-alt/:id',function(req, res){
    const { id } = req.params;
    pool.query(`SELECT id, nome, to_char( dtnascimento, 'YYYY-MM-DD') as dtnascimento, cpf, email, telefone, estadocivil, curso
                 FROM estudantes WHERE ID = ${id}`)
                 .then(function(resultado){
                    let estudante = resultado.rows[0]
                    //console.log(estudante)
                    res.render('form-album',{estudante})
                })
                .catch(function(erro){
                    console.log(erro.stack)
                    //res.render('lista');
                })
});
 */


app.post('/alt/:id',function(req, res){
    const { id } = req.params;
    pool.query(`
                UPDATE estudantes SET
		            nome = '${req.body.nome}',
                    dtnascimento = '${req.body.dataNascimento}',
                    cpf = '${req.body.cpf}',
                    email = '${req.body.email}',
                    telefone = '${req.body.telWhats}',
                    estadocivil = ${req.body.estCivil},
                    curso = ${req.body.curso}
	            WHERE 
                    ID = ${id}`)
                .then(function(retorno){
                    //console.log("Alteração realizada com sucesso!")
                    //throw "erro"
                    res.redirect('/listar')
                })
                //TRATAR ERROS NA CAMADA VISUAL
                .catch(function(erro){
                    console.log('Apresentou erro: ' + erro);
                    res.redirect(`/solicita-alterar/${id}`)
                })
});

app.get('/delete/:id',function(req, res){
    const { id } = req.params;
    pool.query(`
                DELETE FROM animais
	            WHERE 
                    ID = ${id}`)
                .then(function(retorno){
                    console.log("Registro excluído com sucesso!")
                    //throw "erro"
                    res.redirect('/listar')
                })
                //TRATAR ERROS NA CAMADA VISUAL
                .catch(function(erro){
                    console.log('Apresentou erro: ' + erro);
                    res.redirect('/listar')
                })
});

app.listen(port, () => console.log(`Rodando porta ${port}`));