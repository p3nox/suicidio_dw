const express = require("express");
const app = express();

/**
 * Colocar servidor no ar
 * process.env.PORT     -> Variável de ambiente.
 */
const PORTA = process.env.PORT || 8081;
app.listen(PORTA,function(){
    console.log('Servidor rodando na porta 8081');
});

/**
 * Configuração do parser para requisições post
 */
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}))

/**
 * Configurações das páginas
 */
app.set('views',__dirname+'/views');
app.set('view engine','pug');

/**
 * caminhos estaticos
 * ./           -> indica o diretório raiz do projeto
 * __dirname    -> retorna o diretório do arquivo que está sendo executado, no caso, o server.js
 */
app.use('/bscss', express.static('./node_modules/bootstrap/dist/css'));
app.use('/bsjs', express.static('./node_modules/bootstrap/dist/js'));
app.use('/popperjs', express.static('./node_modules/@popperjs/core/dist/umd'));
app.use('/jquery', express.static('./node_modules/jquery/dist'));
app.use('/mask', express.static('./node_modules/jquery-mask-plugin/dist'));
app.use('/publico', express.static(__dirname + '/publico'));


/**
 * Conexão com banco de dados via pool de conexões
 * https://node-postgres.com/
 */
const pool = require('./dao/conexao');

/**
 * Requisições
 */
app.get('/form-album',function(req, res){
    res.render('form-album');
});

app.get('/listar',function(req, res){

    pool.query(`SELECT id, nome, to_char( dtnascimento, 'DD-MON-YYYY') as dtnascimento, cpf, email, telefone, estadocivil, curso
                 FROM estudantes ORDER BY ID ASC`)
        .then(function(resultado){
            resultado.rows.forEach( function(row){
                //console.log(row.nome,row.dtnascimento)
            })
            let listaCompleta = resultado.rows
            res.render('listar',{listaCompleta})
        })
        .catch(function(erro){
            console.log(erro.stack)
            //res.render('lista');
        })
});

app.post('/cadastro-album',function(req, res){

    pool.query(`
                INSERT INTO estudantes 
		            (nome, dtnascimento, cpf, email, telefone, estadocivil, curso) 
	            VALUES
                    ($1, $2, $3, $4, $5, $6, $7)`,
        [req.body.nome,
            req.body.dataNascimento,
            req.body.cpf,
            req.body.email,
            req.body.telWhats,
            req.body.estCivil,
            req.body.curso]
    )
        .then(function(retorno){
            console.log("Cadastro realizado com sucesso!")
            res.sendFile(__dirname + '/views/form-success.html');
        })
        .catch(function(erro){
            console.log('Apresentou erro: ' + erro);
            res.sendFile(__dirname + '/views/form_error.html');
        })
});

app.get('/solicita-alterar/:id',function(req, res){
    const { id } = req.params;
    pool.query(`SELECT id, nome, to_char( dtnascimento, 'YYYY-MM-DD') as dtnascimento, cpf, email, telefone, estadocivil, curso
                 FROM estudantes WHERE ID = ${id}`)
        .then(function(resultado){
            let estudante = resultado.rows[0]
            //console.log(estudante)
            res.render('form-album',{estudante})
        })
        .catch(function(erro){
            console.log(erro.stack)
            //res.render('lista');
        })
});

app.post('/alterar/:id',function(req, res){
    const { id } = req.params;
    pool.query(`
                UPDATE estudantes SET
		            nome = '${req.body.nome}',
                    dtnascimento = '${req.body.dataNascimento}',
                    cpf = '${req.body.cpf}',
                    email = '${req.body.email}',
                    telefone = '${req.body.telWhats}',
                    estadocivil = ${req.body.estCivil},
                    curso = ${req.body.curso}
	            WHERE 
                    ID = ${id}`)
        .then(function(retorno){
            //console.log("Alteração realizada com sucesso!")
            throw "erro"
            //res.redirect('/listar')
        })
        //TRATAR ERROS NA CAMADA VISUAL
        .catch(function(erro){
            console.log('Apresentou erro: ' + erro);
            res.redirect(`/solicita-alterar/${id}`)
        })
});