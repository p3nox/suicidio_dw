CREATE TABLE doges(

	aidi SERIAL PRIMARY KEY,
	nome VARCHAR,
	raca VARCHAR,
	idade INTEGER

);